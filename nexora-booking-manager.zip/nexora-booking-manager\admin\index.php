﻿<?php
// Silence is golden.
